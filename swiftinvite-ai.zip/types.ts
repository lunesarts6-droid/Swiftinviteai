
export enum AppView {
  HOME = 'HOME',
  GENERATOR = 'GENERATOR',
  EDITOR = 'EDITOR'
}

export type EventType = 'Wedding' | 'Engagement' | 'Birthday' | 'Graduation' | 'Baby Shower';

export type AspectRatio = '5:7' | '1:1' | '2:3' | '4:3';

export interface TextLayer {
  id: string;
  text: string;
  fontSize: number;
  top: number; // percentage 0-100
  left: number; // percentage 0-100
  fontWeight?: string;
  color?: string; // hex code
  role?: 'intro' | 'main' | 'desc' | 'date_dayname' | 'date_month' | 'date_daynum' | 'date_year' | 'date_time' | 'location' | 'rsvp';
}

export interface InvitationData {
  eventType: EventType;
  backgroundImage: string; // base64
  textLayers: TextLayer[];
  aspectRatio: AspectRatio;
}
