
import React, { useEffect, useRef, useState } from 'react';
import { InvitationData, TextLayer } from '../types';

// Declare fabric globally as we'll use it from a CDN for simplicity and reliability in this environment
declare const fabric: any;

interface EditorViewProps {
  data: InvitationData;
}

const FONT_FAMILIES = [
  { name: 'Modern (Inter)', value: 'Inter, sans-serif' },
  { name: 'Elegant (Playfair Display)', value: '"Playfair Display", serif' },
  { name: 'Clean (Montserrat)', value: 'Montserrat, sans-serif' },
  { name: 'Script (Dancing Script)', value: '"Dancing Script", cursive' },
  { name: 'Classic (Roboto Mono)', value: '"Roboto Mono", monospace' },
];

const GRID_SIZE = 10;

const EditorView: React.FC<EditorViewProps> = ({ data }) => {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const fabricCanvas = useRef<any>(null);
  const [isLoaded, setIsLoaded] = useState(false);
  const [selectedObject, setSelectedObject] = useState<any>(null);
  const [snapToGrid, setSnapToGrid] = useState(false);
  // Dummy state to force React re-render when Fabric objects are mutated internally
  const [, setTick] = useState(0);

  const forceUpdate = () => setTick(t => t + 1);

  useEffect(() => {
    // Load Fabric.js from CDN
    const script = document.createElement('script');
    script.src = 'https://cdnjs.cloudflare.com/ajax/libs/fabric.js/5.3.1/fabric.min.js';
    script.onload = () => initCanvas();
    document.body.appendChild(script);

    const handleKeyDown = (e: KeyboardEvent) => {
      if (!fabricCanvas.current) return;
      const activeObject = fabricCanvas.current.getActiveObject();
      if (!activeObject || activeObject.isEditing) return;

      const moveAmount = e.shiftKey ? 10 : 1;

      switch (e.key) {
        case 'ArrowUp':
          activeObject.set('top', activeObject.top - moveAmount);
          e.preventDefault();
          break;
        case 'ArrowDown':
          activeObject.set('top', activeObject.top + moveAmount);
          e.preventDefault();
          break;
        case 'ArrowLeft':
          activeObject.set('left', activeObject.left - moveAmount);
          e.preventDefault();
          break;
        case 'ArrowRight':
          activeObject.set('left', activeObject.left + moveAmount);
          e.preventDefault();
          break;
        case 'Delete':
        case 'Backspace':
          // Optional: allow deleting elements if not background
          if (!activeObject.selectable) return;
          fabricCanvas.current.remove(activeObject);
          fabricCanvas.current.discardActiveObject();
          break;
      }
      
      if (['ArrowUp', 'ArrowDown', 'ArrowLeft', 'ArrowRight'].includes(e.key)) {
        activeObject.setCoords();
        fabricCanvas.current.requestRenderAll();
        forceUpdate();
      }
    };

    window.addEventListener('keydown', handleKeyDown);

    return () => {
      if (fabricCanvas.current) {
        fabricCanvas.current.dispose();
      }
      if (document.body.contains(script)) {
        document.body.removeChild(script);
      }
      window.removeEventListener('keydown', handleKeyDown);
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  // Update snapping behavior when toggle changes
  useEffect(() => {
    if (!fabricCanvas.current) return;
    
    const handleMoving = (options: any) => {
      if (!snapToGrid) return;
      options.target.set({
        left: Math.round(options.target.left / GRID_SIZE) * GRID_SIZE,
        top: Math.round(options.target.top / GRID_SIZE) * GRID_SIZE
      });
    };

    fabricCanvas.current.off('object:moving');
    if (snapToGrid) {
      fabricCanvas.current.on('object:moving', handleMoving);
    }
  }, [snapToGrid]);

  const getCanvasDimensions = () => {
    const maxWidth = Math.min(window.innerWidth - 48, 500);
    const maxHeight = window.innerHeight * 0.65;
    
    let ratio = 1; // height / width
    switch(data.aspectRatio) {
      case '1:1': ratio = 1; break;
      case '5:7': ratio = 7/5; break;
      case '2:3': ratio = 3/2; break;
      case '4:3': ratio = 3/4; break;
      default: ratio = 7/5;
    }

    let width = maxWidth;
    let height = width * ratio;

    if (height > maxHeight) {
      height = maxHeight;
      width = height / ratio;
    }

    return { width, height };
  };

  const initCanvas = () => {
    if (!canvasRef.current) return;

    const { width, height } = getCanvasDimensions();

    fabricCanvas.current = new fabric.Canvas(canvasRef.current, {
      width,
      height,
      backgroundColor: '#ffffff',
      preserveObjectStacking: true,
    });

    // Listen for selection events to update UI
    fabricCanvas.current.on('selection:created', (e: any) => setSelectedObject(e.selected[0]));
    fabricCanvas.current.on('selection:updated', (e: any) => setSelectedObject(e.selected[0]));
    fabricCanvas.current.on('selection:cleared', () => setSelectedObject(null));
    
    // Also listen for object modification (dragging, scaling) to refresh UI if needed
    fabricCanvas.current.on('object:modified', () => forceUpdate());
    fabricCanvas.current.on('object:scaling', () => forceUpdate());

    fabric.Image.fromURL(data.backgroundImage, (img: any) => {
      const scaleX = width / img.width;
      const scaleY = height / img.height;
      const scale = Math.max(scaleX, scaleY);
      
      img.set({
        originX: 'center',
        originY: 'center',
        scaleX: scale,
        scaleY: scale,
        selectable: false,
        evented: false,
        left: width / 2,
        top: height / 2,
      });
      
      fabricCanvas.current.setBackgroundImage(img, fabricCanvas.current.renderAll.bind(fabricCanvas.current));
      
      const textColor = data.textLayers[0]?.color || '#333333';

      data.textLayers.forEach((layer) => {
        const text = new fabric.IText(layer.text, {
          left: (layer.left / 100) * width,
          top: (layer.top / 100) * height,
          fontSize: (layer.fontSize / 500) * width,
          fontFamily: layer.role === 'date_daynum' || layer.role === 'main' ? '"Playfair Display", serif' : 'Inter, sans-serif',
          fontWeight: layer.fontWeight || 'normal',
          fill: layer.color || textColor,
          originX: 'center',
          originY: 'center',
          textAlign: 'center',
          cornerStyle: 'circle',
          cornerColor: '#4f46e5',
          cornerSize: 10,
          transparentCorners: false,
          borderColor: '#4f46e5',
          padding: 10, 
          hasRotatingPoint: true,
          rotatingPointOffset: 20,
          stroke: null,
          strokeWidth: 0,
          paintFirst: 'stroke',
        });
        fabricCanvas.current.add(text);
      });

      // Add Vertical Dividers for the Date Block
      const dateY = (60 / 100) * height;
      const leftLineX = (42 / 100) * width;
      const rightLineX = (58 / 100) * width;
      const lineLength = (5 / 100) * height;

      const createLine = (x: number) => new fabric.Line([x, dateY - lineLength, x, dateY + lineLength], {
        stroke: textColor,
        strokeWidth: 2,
        selectable: true,
        opacity: 0.5,
        padding: 20, 
        cornerStyle: 'circle',
        cornerColor: '#4f46e5',
        cornerSize: 8,
        transparentCorners: false,
        borderColor: '#4f46e5',
        hasRotatingPoint: false,
      });

      fabricCanvas.current.add(createLine(leftLineX));
      fabricCanvas.current.add(createLine(rightLineX));

      fabricCanvas.current.renderAll();
      setIsLoaded(true);
    });
  };

  const handleDownload = () => {
    if (!fabricCanvas.current) return;
    fabricCanvas.current.discardActiveObject().renderAll();
    const dataURL = fabricCanvas.current.toDataURL({
      format: 'png',
      quality: 1.0,
      multiplier: 2,
    });
    const link = document.createElement('a');
    link.download = `Invitation-${data.eventType}.png`;
    link.href = dataURL;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  const updateSelectedStyle = (property: string, value: any) => {
    if (!fabricCanvas.current) return;
    const activeObject = fabricCanvas.current.getActiveObject();
    if (!activeObject) return;
    
    activeObject.set(property, value);
    fabricCanvas.current.requestRenderAll();
    forceUpdate();
  };

  const moveForward = () => {
    if (!fabricCanvas.current || !selectedObject) return;
    fabricCanvas.current.bringForward(selectedObject);
    fabricCanvas.current.requestRenderAll();
  };

  const moveBackward = () => {
    if (!fabricCanvas.current || !selectedObject) return;
    fabricCanvas.current.sendBackwards(selectedObject);
    fabricCanvas.current.requestRenderAll();
  };

  const moveFront = () => {
    if (!fabricCanvas.current || !selectedObject) return;
    fabricCanvas.current.bringToFront(selectedObject);
    fabricCanvas.current.requestRenderAll();
  };

  const moveBack = () => {
    if (!fabricCanvas.current || !selectedObject) return;
    fabricCanvas.current.sendToBack(selectedObject);
    fabricCanvas.current.requestRenderAll();
  };

  const toggleBold = () => {
    if (!selectedObject) return;
    const isBold = selectedObject.fontWeight === 'bold';
    updateSelectedStyle('fontWeight', isBold ? 'normal' : 'bold');
  };

  const toggleItalic = () => {
    if (!selectedObject) return;
    const isItalic = selectedObject.fontStyle === 'italic';
    updateSelectedStyle('fontStyle', isItalic ? 'normal' : 'italic');
  };

  const toggleStroke = () => {
    if (!selectedObject || !isTextSelected) return;
    const hasStroke = !!selectedObject.stroke;
    if (hasStroke) {
      updateSelectedStyle('stroke', null);
      updateSelectedStyle('strokeWidth', 0);
    } else {
      updateSelectedStyle('stroke', '#000000');
      updateSelectedStyle('strokeWidth', 2);
    }
  };

  const isTextSelected = selectedObject && (selectedObject.type === 'i-text' || selectedObject.type === 'text');

  return (
    <div className="flex flex-col items-center animate-in fade-in zoom-in-95 duration-500">
      <div className="w-full max-w-lg mb-6 flex flex-col gap-4 px-4">
        <div className="flex justify-between items-center">
          <div>
            <h3 className="text-xl font-bold text-gray-800">Customize Your Invitation</h3>
            <p className="text-sm text-gray-500 italic">Double-click text to edit, use Arrow keys to nudge</p>
          </div>
          <button
            onClick={handleDownload}
            className="bg-emerald-600 hover:bg-emerald-700 text-white font-bold py-2 px-6 rounded-lg shadow-md transition-all flex items-center gap-2"
          >
            <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 16v1a3 3 0 003 3h10a3 3 0 003-3v-1m-4-4l-4 4m0 0l-4-4m4 4V4" />
            </svg>
            Download
          </button>
        </div>

        {/* Text Formatting Toolbar */}
        <div className={`flex flex-col gap-3 p-3 bg-white border border-gray-200 rounded-xl shadow-sm transition-all duration-300 ${selectedObject ? 'opacity-100' : 'opacity-40 pointer-events-none'}`}>
          <div className="flex items-center gap-2">
            <select 
              disabled={!isTextSelected}
              className="flex-1 bg-gray-50 border border-gray-200 rounded-lg px-2 py-1.5 text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500 disabled:opacity-50"
              value={selectedObject?.fontFamily || ''}
              onChange={(e) => updateSelectedStyle('fontFamily', e.target.value)}
            >
              <option value="" disabled>Select Font</option>
              {FONT_FAMILIES.map(font => (
                <option key={font.value} value={font.value}>{font.name}</option>
              ))}
            </select>
            
            <button 
              disabled={!isTextSelected}
              onClick={toggleBold}
              className={`p-1.5 rounded-lg border transition-all disabled:opacity-50 ${selectedObject?.fontWeight === 'bold' ? 'bg-indigo-100 border-indigo-300 text-indigo-700' : 'bg-gray-50 border-gray-200 text-gray-600 hover:bg-gray-100'}`}
              title="Bold"
            >
              <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round">
                <path d="M6 4h8a4 4 0 0 1 4 4 4 4 0 0 1-4 4H6z"></path>
                <path d="M6 12h9a4 4 0 0 1 4 4 4 4 0 0 1-4 4H6z"></path>
              </svg>
            </button>

            <button 
              disabled={!isTextSelected}
              onClick={toggleItalic}
              className={`p-1.5 rounded-lg border transition-all disabled:opacity-50 ${selectedObject?.fontStyle === 'italic' ? 'bg-indigo-100 border-indigo-300 text-indigo-700' : 'bg-gray-50 border-gray-200 text-gray-600 hover:bg-gray-100'}`}
              title="Italic"
            >
              <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round">
                <line x1="19" y1="4" x2="10" y2="4"></line>
                <line x1="14" y1="20" x2="5" y2="20"></line>
                <line x1="15" y1="4" x2="9" y2="20"></line>
              </svg>
            </button>

            <button 
              disabled={!isTextSelected}
              onClick={toggleStroke}
              className={`p-1.5 rounded-lg border transition-all disabled:opacity-50 ${selectedObject?.stroke ? 'bg-indigo-100 border-indigo-300 text-indigo-700' : 'bg-gray-50 border-gray-200 text-gray-600 hover:bg-gray-100'}`}
              title="Outline (Stroke)"
            >
              <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                <circle cx="12" cy="12" r="10"></circle>
                <circle cx="12" cy="12" r="6"></circle>
              </svg>
            </button>

            <div className="h-8 w-px bg-gray-200 mx-1"></div>

            <div className="flex flex-col gap-0.5" title="Fill Color">
              <span className="text-[8px] uppercase font-bold text-gray-400 text-center">Fill</span>
              <input 
                type="color" 
                value={selectedObject?.fill || '#333333'} 
                onChange={(e) => updateSelectedStyle('fill', e.target.value)}
                className="w-7 h-7 p-0.5 bg-white border border-gray-200 rounded-lg cursor-pointer hover:border-indigo-300 transition-colors"
              />
            </div>

            {isTextSelected && selectedObject?.stroke && (
              <div className="flex flex-col gap-0.5" title="Stroke Color">
                <span className="text-[8px] uppercase font-bold text-gray-400 text-center">Line</span>
                <input 
                  type="color" 
                  value={selectedObject?.stroke || '#000000'} 
                  onChange={(e) => updateSelectedStyle('stroke', e.target.value)}
                  className="w-7 h-7 p-0.5 bg-white border border-gray-200 rounded-lg cursor-pointer hover:border-indigo-300 transition-colors"
                />
              </div>
            )}
          </div>

          <div className="flex flex-col gap-2">
            {/* Font Size Slider */}
            <div className="flex items-center gap-3 px-1">
              <span className="text-[10px] font-bold text-gray-400 uppercase w-12">{isTextSelected ? 'Size' : 'Opac'}</span>
              <input 
                type="range"
                min={isTextSelected ? "8" : "0"}
                max={isTextSelected ? "120" : "1"}
                step={isTextSelected ? "1" : "0.1"}
                value={isTextSelected ? (selectedObject?.fontSize || 20) : (selectedObject?.opacity || 0.5)}
                onChange={(e) => updateSelectedStyle(isTextSelected ? 'fontSize' : 'opacity', parseFloat(e.target.value))}
                className="flex-1 h-1.5 bg-gray-200 rounded-lg appearance-none cursor-pointer accent-indigo-600"
              />
              <span className="text-xs font-mono text-gray-500 w-8">
                {isTextSelected ? Math.round(selectedObject?.fontSize || 0) : (selectedObject?.opacity || 0).toFixed(1)}
              </span>
            </div>

            {/* Stroke Width Slider (Conditional) */}
            {isTextSelected && selectedObject?.stroke && (
              <div className="flex items-center gap-3 px-1">
                <span className="text-[10px] font-bold text-gray-400 uppercase w-12">Outline</span>
                <input 
                  type="range"
                  min="0.5"
                  max="10"
                  step="0.5"
                  value={selectedObject?.strokeWidth || 2}
                  onChange={(e) => updateSelectedStyle('strokeWidth', parseFloat(e.target.value))}
                  className="flex-1 h-1.5 bg-gray-200 rounded-lg appearance-none cursor-pointer accent-indigo-600"
                />
                <span className="text-xs font-mono text-gray-500 w-8">
                  {(selectedObject?.strokeWidth || 0).toFixed(1)}
                </span>
              </div>
            )}
          </div>
        </div>

        {/* Global Editor Settings & Stacking */}
        <div className="grid grid-cols-2 gap-3">
          <div className="flex items-center gap-2 px-3 py-2 bg-gray-50 border border-gray-200 rounded-xl">
            <input 
              type="checkbox" 
              id="snap-grid"
              checked={snapToGrid}
              onChange={(e) => setSnapToGrid(e.target.checked)}
              className="w-4 h-4 text-indigo-600 border-gray-300 rounded focus:ring-indigo-500"
            />
            <label htmlFor="snap-grid" className="text-xs font-medium text-gray-700 cursor-pointer">
              Snap to Grid
            </label>
          </div>

          <div className="flex items-center justify-around px-2 py-1 bg-white border border-gray-200 rounded-xl shadow-sm">
            <button 
              onClick={moveFront}
              className="p-1.5 hover:bg-gray-100 rounded-lg text-gray-600"
              title="Bring to Front"
            >
              <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M4 14l8-8 8 8"/><path d="M4 20h16"/></svg>
            </button>
            <button 
              onClick={moveForward}
              className="p-1.5 hover:bg-gray-100 rounded-lg text-gray-600"
              title="Bring Forward"
            >
              <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M18 15l-6-6-6 6"/></svg>
            </button>
            <button 
              onClick={moveBackward}
              className="p-1.5 hover:bg-gray-100 rounded-lg text-gray-600"
              title="Send Backward"
            >
              <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M6 9l6 6 6-6"/></svg>
            </button>
            <button 
              onClick={moveBack}
              className="p-1.5 hover:bg-gray-100 rounded-lg text-gray-600"
              title="Send to Back"
            >
              <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M4 4h16"/><path d="M4 10l8 8 8-8"/></svg>
            </button>
          </div>
        </div>
      </div>

      <div className="canvas-wrapper relative bg-white p-2 rounded-xl shadow-2xl">
        {!isLoaded && (
          <div className="absolute inset-0 flex items-center justify-center bg-gray-50 bg-opacity-80 z-10 rounded-xl">
             <div className="animate-pulse text-indigo-600 font-medium">Initializing Editor...</div>
          </div>
        )}
        <canvas ref={canvasRef} id="invitation-canvas" />
      </div>

      <div className="mt-8 text-center text-gray-400 text-xs">
        Powered by SwiftInvite AI • Gemini Vision & Flash
      </div>
    </div>
  );
};

export default EditorView;
