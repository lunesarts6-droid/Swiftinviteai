
import React from 'react';
import { EventType } from '../types';

interface HomeViewProps {
  onSelect: (event: EventType) => void;
}

const EVENTS: { name: EventType; icon: string; color: string }[] = [
  { name: 'Wedding', icon: '💍', color: 'bg-rose-50' },
  { name: 'Engagement', icon: '🥂', color: 'bg-amber-50' },
  { name: 'Birthday', icon: '🎂', color: 'bg-sky-50' },
  { name: 'Graduation', icon: '🎓', color: 'bg-emerald-50' },
  { name: 'Baby Shower', icon: '👶', color: 'bg-purple-50' },
];

const HomeView: React.FC<HomeViewProps> = ({ onSelect }) => {
  return (
    <div className="max-w-4xl mx-auto text-center animate-in fade-in slide-in-from-bottom-4 duration-700">
      <h2 className="text-4xl font-extrabold text-gray-900 mb-4">Create Your Invitation</h2>
      <p className="text-gray-600 mb-12 text-lg">Choose an event type to start generating with AI</p>
      
      <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-5 gap-6">
        {EVENTS.map((event) => (
          <button
            key={event.name}
            onClick={() => onSelect(event.name)}
            className={`${event.color} p-8 rounded-3xl border-2 border-transparent hover:border-indigo-400 hover:shadow-xl transition-all duration-300 flex flex-col items-center group`}
          >
            <span className="text-5xl mb-4 group-hover:scale-110 transition-transform duration-300">{event.icon}</span>
            <span className="font-semibold text-gray-800 text-lg">{event.name}</span>
          </button>
        ))}
      </div>
    </div>
  );
};

export default HomeView;
